/* 
This contains some constant values that could be used throughout the app
It is not need and could be ignored
*/
export default {
    primary: '#fc9208'
}